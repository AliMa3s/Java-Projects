/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;


import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import org.testng.annotations.Test;

/**
 *
 * @author alima
 */
public class CursusNGTest {
     private static EntityManagerFactory factory = 
            Persistence.createEntityManagerFactory("Opdracht-JPAPU");
    public CursusNGTest() {
    }
    
    @Test
    public void alleCursus(){
        System.out.println("Alle cursus");
        EntityManager em = factory.createEntityManager();
        Query zoek = em.createNamedQuery("Cursus.findAll");
        List<Cursus> cursus = zoek.getResultList();
        cursus.forEach(rij -> System.out.println(rij));
        em.close();
        
    }
    @Test
    public void alleStudenten(){
         System.out.println("Alle Studenten");
        EntityManager em = factory.createEntityManager();
        Query zoek = em.createNamedQuery("Student.findAll");
        List<Student> student = zoek.getResultList();
        student.forEach(rij -> System.out.println(rij));
        em.close();
    }
    
    @Test
    public void nieuweStudent(){
        System.out.println("Toevoegen van Student");
        String studentnaam = "Jens";
        String stadStudent = "Antwerpen";
        Student student = new Student(studentnaam, stadStudent);
        EntityManager em = factory.createEntityManager();
        EntityTransaction tr = em.getTransaction();
        tr.begin();
        em.persist(student);
        tr.commit();
        em.close();
//        em = factory.createEntityManager();
//        assertNotNull(em.find(Docent.class, 7), "Docent is gemaakt");
//        em.close();
        //CHECK VIDEO AT 21:30
//OPZOEKEN
        em = factory.createEntityManager();
        Query query = em.createNamedQuery("Student.findByNaam");
        query.setParameter("naam", studentnaam);
        List<Docent> resultaat = query.getResultList();
        System.out.println("gevonden Student: " + resultaat);
        em.close();
    }
    
}
