/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import db.Cursus;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author alima
 */
public class CursusModel extends DefaultTableModel {
   private ArrayList<Cursus> data;

    public CursusModel(ArrayList<Cursus> data) {
        this.data = data;
        super.setColumnIdentifiers(new String[]{"Cursus"});
    }

//    @Override
    public int getRowCount() {
        return data != null ? data.size() : 0;
    }

//    @Override
    public Object getValueAt(int row, int column) {
         Cursus index = data.get(row);
        switch(column){
            case 0: return index.getVak();
//             case 1: return index.getLid();
//             case 2: return index.getEinddatum();
             default: return null;
        }
    }
} 

