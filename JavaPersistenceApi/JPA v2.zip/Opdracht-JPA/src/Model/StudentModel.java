/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import UI.SchoolAdministratie;
import db.Cursus;
import db.Student;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author alima
 */
public class StudentModel extends DefaultTableModel{

    private ArrayList<Student> data;

    public StudentModel(ArrayList<Student> data) {
        this.data = data;
        super.setColumnIdentifiers(new String[]{"Student"});
    }

    @Override
    public int getRowCount() {
        return data != null ? data.size() : 0;
    }

    @Override
    public Object getValueAt(int row, int column) {
         Student index = data.get(row);
        switch(column){
            case 0: return index.getNaam();
//             case 1: return index.getLid();
//             case 2: return index.getEinddatum();
             default: return null;
        }
    }
}

