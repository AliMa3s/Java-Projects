/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Persistence;
import javax.persistence.Table;

/**
 *
 * @author alima
 */
@Entity
@Table(name = "inschrijving")
@NamedQueries({
    @NamedQuery(name = "Inschrijving.findAll", query = "SELECT i FROM Inschrijving i"),
    @NamedQuery(name = "Inschrijving.findById", query = "SELECT i FROM Inschrijving i WHERE i.id = :id")})
public class Inschrijving implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @JoinColumn(name = "planning_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Planning planning;
    @JoinColumn(name = "student_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Student student;

    public Inschrijving() {
    }

    public Inschrijving(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Planning getPlanning() {
        return planning;
    }

    public void setPlanning(Planning planning) {
        this.planning = planning;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
      private static EntityManagerFactory factory = 
            Persistence.createEntityManagerFactory("Opdracht-JPAPU");

    public Inschrijving(Planning planning, Student student) {
        this.planning = planning;
        this.student = student;
    }
      
    public void InschrijfStudent(){
        Student st = new Student();
        Planning pln = new Planning();
        Inschrijving student = new Inschrijving(pln, st);
//        if(!st.){
        EntityManager em = factory.createEntityManager();
        EntityTransaction tr = em.getTransaction();
        tr.begin();
        em.persist(student);
        tr.commit();
        em.close(); 
//        }

    }
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Inschrijving)) {
            return false;
        }
        Inschrijving other = (Inschrijving) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "db.Inschrijving[ id=" + id + " ]";
    }
    
}
