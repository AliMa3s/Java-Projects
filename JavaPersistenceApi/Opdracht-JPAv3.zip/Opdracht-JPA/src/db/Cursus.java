/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.Table;
import javax.swing.DefaultListModel;
import javax.swing.JList;

/**
 *
 * @author alima
 */
@Entity
@Table(name = "cursus")
@NamedQueries({
    @NamedQuery(name = "Cursus.findAll", query = "SELECT c FROM Cursus c"),
    @NamedQuery(name = "Cursus.findById", query = "SELECT c FROM Cursus c WHERE c.id = :id"),
    @NamedQuery(name = "Cursus.findByCode", query = "SELECT c FROM Cursus c WHERE c.code = :code"),
    @NamedQuery(name = "Cursus.findByVak", query = "SELECT c FROM Cursus c WHERE c.vak = :vak")})
public class Cursus implements Serializable {
     private static EntityManagerFactory factory = 
            Persistence.createEntityManagerFactory("Opdracht-JPAPU");
    
     
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @Column(name = "vak")
    private String vak;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cursus")
    private List<Planning> planningList;

    public Cursus() {
    }

    public Cursus(Integer id) {
        this.id = id;
    }

    public Cursus(Integer id, String code, String vak) {
        this.id = id;
        this.code = code;
        this.vak = vak;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getVak() {
        return vak;
    }

    public void setVak(String vak) {
        this.vak = vak;
    }

    public List<Planning> getPlanningList() {
        return planningList;
    }

    public void setPlanningList(List<Planning> planningList) {
        this.planningList = planningList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }
    
//    public void alleCursus(){
//        System.out.println("Alle cursus");
//        EntityManager em = factory.createEntityManager();
//        Query zoek = em.createNamedQuery("Cursus.findAll");
//        List<Cursus> cursus = zoek.getResultList();
//        cursus.forEach(rij -> System.out.println(rij));
//        em.close();
//    }
//    
//        public List alleCursuss(){
//            DefaultListModel dlm = new DefaultListModel();
//            EntityManager em = factory.createEntityManager();
//            Query zoek = em.createNamedQuery("Cursus.findAll");
//            List<Cursus> cursusLijst = zoek.getResultList();
//            cursusLijst.forEach(rij -> dlm.addElement(dlm));
//            
//            em.close();
//            return cursusLijst;
//            
//        }
            public ArrayList<Cursus> alleCursus(){
        ArrayList<Cursus> cursusArray = new ArrayList<>();
        EntityManager em = factory.createEntityManager();
        Query zoek = em.createNamedQuery("Cursus.findAll");
        List<Cursus> cursus = zoek.getResultList();
        String[] studentData = new String[cursus.size()];
                for(int i = 0; i < cursus.size(); i++){
////                    listData[i] = student.get(i);
                    studentData[i] = cursus.get(i).toString();
                    cursusArray.add(cursus.get(i));
                }
                
              em.close();
              return cursusArray;
   
        }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cursus)) {
            return false;
        }
        Cursus other = (Cursus) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return vak;
    }
    
}
