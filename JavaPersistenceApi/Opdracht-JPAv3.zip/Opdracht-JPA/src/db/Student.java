/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.Table;

/**
 *
 * @author alima
 */
@Entity
@Table(name = "student")
@NamedQueries({
    @NamedQuery(name = "Student.findAll", query = "SELECT s FROM Student s"),
    @NamedQuery(name = "Student.findById", query = "SELECT s FROM Student s WHERE s.id = :id"),
    @NamedQuery(name = "Student.findByNaam", query = "SELECT s FROM Student s WHERE s.naam = :naam"),
    @NamedQuery(name = "Student.findByStad", query = "SELECT s FROM Student s WHERE s.stad = :stad")})
public class Student implements Serializable {
     private static EntityManagerFactory factory = 
            Persistence.createEntityManagerFactory("Opdracht-JPAPU");
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "naam")
    private String naam;
    @Basic(optional = false)
    @Column(name = "stad")
    private String stad;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "student")
//    private Planning planning;
    private List<Inschrijving> inschrijvingList;
    
    public Student() {
    }

    public Student(Integer id) {
        this.id = id;
    }
    
     public Student(String naam, String stad) {
        this.id = id;
        this.naam = naam;
        this.stad = stad;
    }   
//        public Student(String naam, String stad, Planning planning) {
//        this.id = id;
//        this.naam = naam;
//        this.stad = stad;
//        this.planning = planning;
//    }
    public Student(Integer id, String naam, String stad) {
        this.id = id;
        this.naam = naam;
        this.stad = stad;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public String getStad() {
        return stad;
    }

    public void setStad(String stad) {
        this.stad = stad;
    }

    public List<Inschrijving> getInschrijvingList() {
        return inschrijvingList;
    }

    public void setInschrijvingList(List<Inschrijving> inschrijvingList) {
        this.inschrijvingList = inschrijvingList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Student)) {
            return false;
        }
        Student other = (Student) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }
        public ArrayList<Student> alleStudenten(){
        ArrayList<Student> studentArray = new ArrayList<>();
        EntityManager em = factory.createEntityManager();
        Query zoek = em.createNamedQuery("Student.findAll");
        List<Student> student = zoek.getResultList();
        String[] studentData = new String[student.size()];
                for(int i = 0; i < student.size(); i++){
////                    listData[i] = student.get(i);
                    studentData[i] = student.get(i).toString();
                    studentArray.add(student.get(i));
                }
                
              em.close();
              return studentArray;
   
        } 

        public void AddStudent(String naam, String stad){
        Student student = new Student(naam, stad);
        EntityManager em = factory.createEntityManager();
        EntityTransaction tr = em.getTransaction();
        tr.begin();
        em.persist(student);
        tr.commit();
        em.close();
        }
        
//        public void AddStudentWithPlanning(String naam, String stad, Planning planning){
//            
//            Student std = new Student(naam, stad);
//            EntityManager em = factory.createEntityManager();
//            EntityTransaction tr = em.getTransaction();
//            tr.begin();
//            em.persist(std);
//            tr.commit();
//            em.close();
//        }
        
    @Override
    public String toString() {
        return  naam;
    }
    
}
